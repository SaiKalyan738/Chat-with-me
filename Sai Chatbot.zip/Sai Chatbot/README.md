# Attractive Advance Portfolio Website
## _Chatting Bot Like Design (Whatsapp like interface)_


- [Running Site](https://github.com/SaiKalyan738)

[![N|Solid]](https://github.com/SaiKalyan738)

## Technologies Used

- HTML
- Javascript
- CSS

## Features

- Whatsapp like interface
- Pleasant sounds
- Lightweighted
- Social media links
- Download resume.
- Map support for address
- Random replies for hi, bye, i love you.

<br><br>

## Connect with Me: 

<br>

[![N|Solid]](https://t.me/sai7335)


[![N|Solid]](https://instagram.com/sai_kalyan_n/)


<br>

